#include <iostream>
#include <string>
void main()
{
}